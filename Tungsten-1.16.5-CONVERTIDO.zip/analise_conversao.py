#!/usr/bin/env python3
"""
Script de Análise de Conversão do Mod Tungsten para 1.16.5
Identifica mudanças necessárias nos arquivos Java
"""

import os
import re
from pathlib import Path
from collections import defaultdict

class ConversaoAnalyzer:
    def __init__(self, project_path):
        self.project_path = Path(project_path)
        self.java_files = []
        self.issues = defaultdict(list)
        self.stats = {
            'total_files': 0,
            'total_lines': 0,
            'imports_problematicos': 0,
            'metodos_descontinuados': 0,
            'classes_renomeadas': 0
        }
        
        # Mapeamento de mudanças de API
        self.api_changes = {
            'net.minecraft.world.World': {
                'novo': 'net.minecraft.server.world.ServerWorld',
                'tipo': 'class_rename',
                'descricao': 'World foi renomeada para ServerWorld em 1.16.5'
            },
            'net.minecraft.client.render.RenderLayer': {
                'novo': 'net.minecraft.client.render.RenderLayer',
                'tipo': 'api_change',
                'descricao': 'Métodos de RenderLayer foram alterados'
            },
            'CommandRegistrationCallback': {
                'novo': 'ServerLifecycleEvents.SERVER_STARTED',
                'tipo': 'event_change',
                'descricao': 'Evento de registro de comandos mudou'
            },
            'net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper': {
                'novo': 'REMOVIDO',
                'tipo': 'removed',
                'descricao': 'KeyBindingHelper foi removido em 1.16.5'
            }
        }
        
        # Padrões de busca
        self.patterns = {
            'import_world': re.compile(r'import\s+net\.minecraft\.world\.World\b'),
            'import_command_callback': re.compile(r'import\s+.*CommandRegistrationCallback'),
            'import_keybinding': re.compile(r'import\s+.*KeyBindingHelper'),
            'metodo_getpos': re.compile(r'\.getPos\(\)'),
            'metodo_getvelocity': re.compile(r'\.getVelocity\(\)'),
            'class_world': re.compile(r'\bWorld\s+\w+\s*='),
            'event_register': re.compile(r'\.register\s*\('),
        }
    
    def find_java_files(self):
        """Encontra todos os arquivos Java no projeto"""
        java_dir = self.project_path / 'src' / 'main' / 'java'
        if java_dir.exists():
            self.java_files = list(java_dir.rglob('*.java'))
        return self.java_files
    
    def analyze_file(self, file_path):
        """Analisa um arquivo Java individual"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')
            
            self.stats['total_files'] += 1
            self.stats['total_lines'] += len(lines)
            
            relative_path = file_path.relative_to(self.project_path)
            
            # Verificar imports problemáticos
            for line_num, line in enumerate(lines, 1):
                # Verificar World import
                if self.patterns['import_world'].search(line):
                    self.issues[str(relative_path)].append({
                        'linha': line_num,
                        'tipo': 'import_world',
                        'mensagem': 'Import de World encontrado - pode precisar de ServerWorld',
                        'sugestao': 'Verifique se deve usar ServerWorld em vez de World',
                        'severidade': 'AVISO'
                    })
                    self.stats['imports_problematicos'] += 1
                
                # Verificar CommandRegistrationCallback
                if self.patterns['import_command_callback'].search(line):
                    self.issues[str(relative_path)].append({
                        'linha': line_num,
                        'tipo': 'command_callback',
                        'mensagem': 'CommandRegistrationCallback encontrado - mudou em 1.16.5',
                        'sugestao': 'Use ServerLifecycleEvents.SERVER_STARTED em vez disso',
                        'severidade': 'ERRO'
                    })
                    self.stats['metodos_descontinuados'] += 1
                
                # Verificar KeyBindingHelper
                if self.patterns['import_keybinding'].search(line):
                    self.issues[str(relative_path)].append({
                        'linha': line_num,
                        'tipo': 'keybinding_removed',
                        'mensagem': 'KeyBindingHelper foi removido em 1.16.5',
                        'sugestao': 'Implemente key binding manualmente ou use alternativa',
                        'severidade': 'ERRO'
                    })
                    self.stats['metodos_descontinuados'] += 1
                
                # Verificar uso de World como tipo
                if self.patterns['class_world'].search(line) and 'ServerWorld' not in line:
                    self.issues[str(relative_path)].append({
                        'linha': line_num,
                        'tipo': 'world_type',
                        'mensagem': f'Uso de World como tipo: {line.strip()}',
                        'sugestao': 'Considere usar ServerWorld se for servidor',
                        'severidade': 'AVISO'
                    })
        
        except Exception as e:
            self.issues[str(relative_path)].append({
                'linha': 0,
                'tipo': 'erro_leitura',
                'mensagem': f'Erro ao ler arquivo: {str(e)}',
                'sugestao': 'Verifique permissões e encoding',
                'severidade': 'ERRO'
            })
    
    def analyze_all(self):
        """Analisa todos os arquivos Java"""
        self.find_java_files()
        print(f"🔍 Analisando {len(self.java_files)} arquivos Java...\n")
        
        for java_file in self.java_files:
            self.analyze_file(java_file)
    
    def generate_report(self):
        """Gera relatório de análise"""
        report = []
        report.append("=" * 80)
        report.append("RELATÓRIO DE ANÁLISE DE CONVERSÃO - TUNGSTEN 1.16.5")
        report.append("=" * 80)
        report.append("")
        
        # Estatísticas
        report.append("📊 ESTATÍSTICAS")
        report.append("-" * 80)
        report.append(f"Total de arquivos Java: {self.stats['total_files']}")
        report.append(f"Total de linhas: {self.stats['total_lines']}")
        report.append(f"Imports problemáticos: {self.stats['imports_problematicos']}")
        report.append(f"Métodos descontinuados: {self.stats['metodos_descontinuados']}")
        report.append("")
        
        # Problemas encontrados
        if self.issues:
            report.append("⚠️  PROBLEMAS ENCONTRADOS")
            report.append("-" * 80)
            
            total_issues = sum(len(v) for v in self.issues.values())
            report.append(f"Total de problemas: {total_issues}\n")
            
            for file_path in sorted(self.issues.keys()):
                report.append(f"\n📄 {file_path}")
                report.append("  " + "-" * 76)
                
                for issue in self.issues[file_path]:
                    report.append(f"  Linha {issue['linha']}: [{issue['severidade']}] {issue['tipo']}")
                    report.append(f"    Mensagem: {issue['mensagem']}")
                    report.append(f"    Sugestão: {issue['sugestao']}")
                    report.append("")
        else:
            report.append("✅ Nenhum problema encontrado!")
        
        report.append("")
        report.append("=" * 80)
        report.append("FIM DO RELATÓRIO")
        report.append("=" * 80)
        
        return "\n".join(report)
    
    def save_report(self, output_file):
        """Salva o relatório em arquivo"""
        report = self.generate_report()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report)
        return output_file

def main():
    import sys
    
    project_path = sys.argv[1] if len(sys.argv) > 1 else '/workspace/Tungsten-1.16.5'
    output_file = sys.argv[2] if len(sys.argv) > 2 else 'RELATORIO_ANALISE.txt'
    
    print(f"🚀 Iniciando análise de conversão...")
    print(f"📁 Projeto: {project_path}")
    print(f"💾 Saída: {output_file}\n")
    
    analyzer = ConversaoAnalyzer(project_path)
    analyzer.analyze_all()
    
    # Exibir relatório
    print(analyzer.generate_report())
    
    # Salvar relatório
    analyzer.save_report(output_file)
    print(f"\n✅ Relatório salvo em: {output_file}")

if __name__ == '__main__':
    main()