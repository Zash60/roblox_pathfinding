# Correções Necessárias para Conversão 1.16.5

## 📊 Resumo da Análise

- **Total de arquivos Java:** 87
- **Total de linhas:** 11.939
- **Problemas encontrados:** 4
- **Erros críticos:** 2
- **Avisos:** 2

---

## 🔴 ERROS CRÍTICOS (Devem ser corrigidos)

### 1. ServerSideTungstenMod.java - Linha 8

**Problema:** `CommandRegistrationCallback` foi removido em 1.16.5

**Arquivo:** `src/main/java/kaptainwutax/tungsten/ServerSideTungstenMod.java`

**Código Atual:**
```java
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
```

**Solução:**
```java
// Remova o import acima e use:
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import com.mojang.brigadier.CommandDispatcher;

// Depois, no método de inicialização:
ServerLifecycleEvents.SERVER_STARTED.register(server -> {
    CommandDispatcher<ServerCommandSource> dispatcher = server.getCommandManager().getDispatcher();
    // Registre seus comandos aqui
});
```

**Explicação:** Em 1.16.5, o sistema de eventos mudou. Use `ServerLifecycleEvents.SERVER_STARTED` para registrar comandos quando o servidor inicia.

---

### 2. TungstenMod.java - Linha 22

**Problema:** `KeyBindingHelper` foi removido em 1.16.5

**Arquivo:** `src/main/java/kaptainwutax/tungsten/TungstenMod.java`

**Código Atual:**
```java
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
```

**Solução - Opção 1 (Recomendado):**
```java
// Implemente key binding manualmente:
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class TungstenKeyBindings {
    public static final KeyBinding TOGGLE_KEY = new KeyBinding(
        "key.tungsten.toggle",
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_T,
        "category.tungsten"
    );
    
    public static void register() {
        // Registre a key binding no cliente
    }
}
```

**Solução - Opção 2 (Se usar Fabric API):**
```java
// Use a API de key binding do Fabric 1.16.5
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
// Nota: Verifique se está disponível na versão 0.28.5 do Fabric API
```

**Explicação:** KeyBindingHelper foi removido, então você precisa registrar key bindings manualmente ou usar uma alternativa do Fabric API 1.16.5.

---

## 🟡 AVISOS (Devem ser verificados)

### 3. TungstenModDataContainer.java - Linha 7

**Problema:** Import de `World` encontrado - pode precisar de `ServerWorld`

**Arquivo:** `src/main/java/kaptainwutax/tungsten/TungstenModDataContainer.java`

**Código Atual:**
```java
import net.minecraft.world.World;
```

**Verificação Necessária:**
```java
// Se a classe usa World para operações de servidor:
import net.minecraft.server.world.ServerWorld;

// Se a classe usa World para operações de cliente:
import net.minecraft.client.world.ClientWorld;

// Se a classe usa World genericamente:
import net.minecraft.world.World;  // Mantém como está
```

**Ação:** Verifique o contexto de uso de `World` neste arquivo. Se for usado apenas no servidor, mude para `ServerWorld`.

---

### 4. MixinWorldChunk.java - Linha 24

**Problema:** Import de `World` encontrado - pode precisar de `ServerWorld`

**Arquivo:** `src/main/java/kaptainwutax/tungsten/mixin/MixinWorldChunk.java`

**Código Atual:**
```java
import net.minecraft.world.World;
```

**Verificação Necessária:**
```java
// Verifique qual tipo de World é usado no mixin
// Se for servidor: use ServerWorld
// Se for cliente: use ClientWorld
// Se for ambos: mantenha World
```

**Ação:** Analise o mixin para determinar se deve usar `ServerWorld` ou `ClientWorld`.

---

## 📋 Checklist de Correções

- [ ] **Corrigir ServerSideTungstenMod.java**
  - [ ] Remover `CommandRegistrationCallback`
  - [ ] Adicionar `ServerLifecycleEvents.SERVER_STARTED`
  - [ ] Testar registro de comandos

- [ ] **Corrigir TungstenMod.java**
  - [ ] Remover ou substituir `KeyBindingHelper`
  - [ ] Implementar key binding manualmente
  - [ ] Testar key binding

- [ ] **Verificar TungstenModDataContainer.java**
  - [ ] Analisar uso de `World`
  - [ ] Decidir entre `World`, `ServerWorld` ou `ClientWorld`
  - [ ] Aplicar correção se necessário

- [ ] **Verificar MixinWorldChunk.java**
  - [ ] Analisar uso de `World` no mixin
  - [ ] Decidir entre `World`, `ServerWorld` ou `ClientWorld`
  - [ ] Aplicar correção se necessário

---

## 🔧 Próximos Passos

1. **Aplicar as correções** listadas acima
2. **Compilar o projeto** com `./gradlew build`
3. **Resolver novos erros** que possam aparecer
4. **Testar o mod** no Minecraft 1.16.5
5. **Ajustar funcionalidades** conforme necessário

---

## 📚 Referências Úteis

- [Fabric API 1.16.5 Changelog](https://github.com/FabricMC/fabric/releases)
- [Minecraft 1.16.5 Mappings](https://mappings.fabricmc.net/)
- [Fabric Documentation](https://fabricmc.net/wiki/documentation)

---

**Data:** 03 de Novembro de 2025
**Versão:** ALPHA-1.6.0-1.16.5