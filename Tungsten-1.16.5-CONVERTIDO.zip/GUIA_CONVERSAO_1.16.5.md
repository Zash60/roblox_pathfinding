# Guia de Conversão do Mod Tungsten para Minecraft 1.16.5

## 📋 Resumo da Conversão

Este documento descreve todas as mudanças necessárias para converter o mod Tungsten de **Minecraft 1.21.8** para **Minecraft 1.16.5**.

---

## 🔧 Mudanças de Configuração (CONCLUÍDAS)

### 1. gradle.properties
**Versão Anterior (1.21.8):**
```properties
minecraft_version=1.21.8
yarn_mappings=1.21.8+build.1
loader_version=0.16.14
fapi_version=0.131.0+1.21.8
```

**Versão Nova (1.16.5):**
```properties
minecraft_version=1.16.5
yarn_mappings=1.16.5+build.1
loader_version=0.11.3
fapi_version=0.28.5+1.16
```

### 2. build.gradle
**Mudanças Principais:**
- Fabric Loom: `1.11-SNAPSHOT` → `0.5-SNAPSHOT`
- Java Version: `VERSION_21` → `VERSION_11`
- Release: `21` → `11`

### 3. fabric.mod.json
**Mudanças:**
- `fabricloader`: `>=0.16.14` → `>=0.11.3`
- `minecraft`: `1.21.8` → `1.16.5`
- `java`: `>=21` → `>=11`
- Removido: `fabric-key-binding-api-v1` (não disponível em 1.16.5)

---

## 🔄 Mudanças de Código Java Necessárias

### 1. **Imports e Pacotes do Fabric API**

#### Mudanças de Eventos
```java
// ❌ ANTIGO (1.21.8)
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;

// ✅ NOVO (1.16.5)
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
// (Mesmos imports, mas com APIs diferentes)
```

#### Mudanças de Renderização
```java
// ❌ ANTIGO (1.21.8)
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderLayer;

// ✅ NOVO (1.16.5)
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderLayer;
// (Mesmos, mas com métodos diferentes)
```

### 2. **Mudanças de Classes Minecraft**

#### Classe `World` → `ServerWorld`
```java
// ❌ ANTIGO
public void onWorldTick(World world) { }

// ✅ NOVO
public void onWorldTick(ServerWorld world) { }
```

#### Classe `Entity` - Mudanças de Métodos
```java
// ❌ ANTIGO (1.21.8)
entity.getPos()  // Retorna Vec3d
entity.getVelocity()  // Retorna Vec3d

// ✅ NOVO (1.16.5)
entity.getPos()  // Retorna Vec3d (igual)
entity.getVelocity()  // Retorna Vec3d (igual)
// Mas alguns métodos foram renomeados
```

#### Classe `BlockPos` - Sem Mudanças Significativas
```java
// Mantém a mesma API
BlockPos pos = new BlockPos(x, y, z);
```

### 3. **Mudanças de Comandos**

#### CommandManager
```java
// ❌ ANTIGO (1.21.8)
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

// ✅ NOVO (1.16.5)
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
// (Mesmos imports)
```

#### Registração de Comandos
```java
// ❌ ANTIGO (1.21.8)
CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
    // Registrar comando
});

// ✅ NOVO (1.16.5)
ServerLifecycleEvents.SERVER_STARTED.register(server -> {
    CommandDispatcher<ServerCommandSource> dispatcher = server.getCommandManager().getDispatcher();
    // Registrar comando
});
```

### 4. **Mudanças de Renderização**

#### MatrixStack
```java
// ❌ ANTIGO (1.21.8)
import net.minecraft.client.util.math.MatrixStack;

// ✅ NOVO (1.16.5)
import net.minecraft.client.util.math.MatrixStack;
// (Mesmo, mas com métodos diferentes)
```

#### Renderização de Linhas
```java
// ❌ ANTIGO (1.21.8)
RenderSystem.lineWidth(2.0f);
// Usar BufferBuilder

// ✅ NOVO (1.16.5)
RenderSystem.lineWidth(2.0f);
// Usar BufferBuilder (similar)
```

### 5. **Mudanças de Mixins**

#### Anotações de Mixin
```java
// ❌ ANTIGO (1.21.8)
@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) { }
}

// ✅ NOVO (1.16.5)
@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) { }
}
// (Mesma sintaxe, mas métodos podem ter mudado)
```

---

## 📦 Dependências Atualizadas

| Dependência | 1.21.8 | 1.16.5 |
|---|---|---|
| Minecraft | 1.21.8 | 1.16.5 |
| Yarn Mappings | 1.21.8+build.1 | 1.16.5+build.1 |
| Fabric Loader | 0.16.14 | 0.11.3 |
| Fabric API | 0.131.0+1.21.8 | 0.28.5+1.16 |
| Java | 21 | 11 |
| Fabric Loom | 1.11-SNAPSHOT | 0.5-SNAPSHOT |

---

## ⚠️ Problemas Comuns e Soluções

### 1. **Erro: `Cannot find symbol: class Vec3d`**
```java
// ✅ Solução
import net.minecraft.util.math.Vec3d;
```

### 2. **Erro: `Method not found: getBlockState()`**
```java
// ❌ ANTIGO
BlockState state = world.getBlockState(pos);

// ✅ NOVO (1.16.5)
BlockState state = world.getBlockState(pos);
// (Mesma sintaxe, mas verifique o tipo de world)
```

### 3. **Erro: `Cannot resolve symbol: ServerCommandSource`**
```java
// ✅ Solução
import net.minecraft.server.command.ServerCommandSource;
```

### 4. **Erro: `Mixin não encontrado`**
- Verifique se o arquivo `tungsten.mixins.json` está correto
- Certifique-se de que os caminhos dos mixins estão corretos

---

## 🔍 Checklist de Conversão

- [x] Atualizar `gradle.properties`
- [x] Atualizar `build.gradle`
- [x] Atualizar `fabric.mod.json`
- [ ] Revisar e atualizar imports Java
- [ ] Converter classes de eventos
- [ ] Atualizar sistema de comandos
- [ ] Converter renderização
- [ ] Testar compilação
- [ ] Testar no Minecraft 1.16.5

---

## 🚀 Próximos Passos

1. **Revisar cada arquivo Java** e aplicar as mudanças necessárias
2. **Compilar o projeto** com `./gradlew build`
3. **Resolver erros de compilação** conforme aparecerem
4. **Testar o mod** no Minecraft 1.16.5
5. **Ajustar funcionalidades** que possam ter mudado

---

## 📚 Referências

- [Fabric Documentation](https://fabricmc.net/wiki/documentation)
- [Minecraft 1.16.5 Mappings](https://mappings.fabricmc.net/)
- [Fabric API Changelog](https://github.com/FabricMC/fabric/releases)

---

**Última atualização:** 03 de Novembro de 2025
**Versão do Mod:** ALPHA-1.6.0-1.16.5