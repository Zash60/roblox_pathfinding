package kaptainwutax.tungsten.world;

public enum Dimension {
    OVERWORLD,
    NETHER,
    END
}