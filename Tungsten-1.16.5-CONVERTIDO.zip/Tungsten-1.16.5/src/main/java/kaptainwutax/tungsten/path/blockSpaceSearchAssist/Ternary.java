package kaptainwutax.tungsten.path.blockSpaceSearchAssist;

public enum Ternary {
    YES, MAYBE, NO
}
