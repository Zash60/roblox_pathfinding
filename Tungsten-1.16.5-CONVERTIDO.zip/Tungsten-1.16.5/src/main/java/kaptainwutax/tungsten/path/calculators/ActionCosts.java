package kaptainwutax.tungsten.path.calculators;

public class ActionCosts {
	public static double COST_INF = -1000000;
	public static double WALK_ONE_BLOCK_COST = 20 / 4.317; // 4.633
}
